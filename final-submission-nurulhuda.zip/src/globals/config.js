const CONFIG = {
  BASE_URL : 'https://notes-api.dicoding.dev/v1',
};

export default CONFIG;
